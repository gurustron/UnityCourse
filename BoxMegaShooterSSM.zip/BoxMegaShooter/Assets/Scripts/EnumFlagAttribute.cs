﻿using UnityEngine;

public class EnumFlagAttribute : PropertyAttribute
{
    public EnumFlagAttribute() { }
}

